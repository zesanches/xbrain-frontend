import styled from "styled-components";

export const PriceBox = styled.div`
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    width: 100%;
    text-align: right;
    gap: 15px;
    margin-top: 30px;
    margin-bottom: 15vh;
    h1{
        margin-bottom: 15px;
    }
    a{
        text-decoration: none;
        margin-top: 10px;
        height: 100px;
        width: fit-content;
        padding: 10px;
        background-color: #ff9800;
        color: #fff;
        border: none;
        outline: none;
        border-radius: 5px;
        font-size: 1.2rem;
        font-weight: bolder;
        font-family: 'Lato' sans-serif;
        cursor: pointer;
    }
`;