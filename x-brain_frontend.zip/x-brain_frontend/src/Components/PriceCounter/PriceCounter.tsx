import React, { useEffect } from 'react'
import { Link } from 'react-router-dom'
import { PriceBox } from './styles'

export default function PriceCounter({ price }: { price: number }) {

    useEffect(() => {
        localStorage.setItem('x-brain@price', price.toString())
    }, [price])

    return (
        <PriceBox>
            <div>
                <h1>Total: R$ {price}</h1>
                <Link to='/billing'>
                    FINALIZAR COMPRA
                </Link>
            </div>
        </PriceBox>
    )
}