import { Product } from "../../Models/types";

export const ListProducts: Product[] = [
    {
        title: 'AirPods Apple Fones de ouvido',
        price: {
            portionX: 12,
            price: 1499,
            discontPercentage: 10
        },
        maxQtd: 5,
        image_url: 'https://t.ctcdn.com.br/FhdQqV_07RxjmirUzjeSob6o2kE=/fit-in/400x400/filters:format(webp):fill(transparent):watermark(wm/prd.png,-32p,center,1,none,15)/i518957.png',
        brand: 'Apple'
    },
    {
        title: 'Capa de silicone para iPhone 8/7 cor Areia - rosa',
        price: {
            portionX: 12,
            price: 299,
            discontPercentage: 10
        },
        maxQtd: null,
        image_url: 'https://photos.enjoei.com.br/public/240x240/czM6Ly9waG90b3MuZW5qb2VpLmNvbS5ici9wcm9kdWN0cy8xMzU0NzgxOC84MmJkOGU4ZGY0M2M0MDQ2Yjg0MTJmNDk2YmNlNzJlYi5qcGc',
        brand: 'Apple'
    },
    {
        title: 'Apple Pencil',
        price: {
            portionX: 12,
            price: 729,
            discontPercentage: 10
        },
        maxQtd: null,
        image_url: 'https://m.media-amazon.com/images/G/32/apple/ACC/ApplePencil1gen._CB647659655_.png',
        brand: 'Apple'
    },
    {
        title: 'Magic Mouse 2 - Prateado',
        price: {
            portionX: 12,
            price: 1499,
            discontPercentage: 10
        },
        maxQtd: null,
        image_url: 'http://d2r9epyceweg5n.cloudfront.net/stores/001/843/519/products/50038699_1350501-c1a58c7fbfb302274116348406414183-640-0.png',
        brand: 'Apple'
    },
    {
        title: 'Caixa prateada de alumínio com relógio esportivo branco',
        price: {
            portionX: 12,
            price: 299,
            discontPercentage: 10
        },
        maxQtd: null,
        image_url: 'https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/42-alu-silver-sport-white-nc-s3-1up_GEO_BR?wid=940&hei=1112&fmt=png-alpha&.v=1594318649000',
        brand: 'Apple'
    },
    {
        title: 'Cado de lightning para UBS (1m)',
        price: {
            portionX: 12,
            price: 729,
            discontPercentage: 10
        },
        maxQtd: null,
        image_url: 'https://cdn.shopify.com/s/files/1/0245/0010/9358/products/type-c-to-light_500x.png?v=1642528449',
        brand: 'Apple'
    },
    {
        title: 'Smart Keyboard para iPad Pro 12.9 polegadas - inglês (EUA)',
        price: {
            portionX: 12,
            price: 1499,
            discontPercentage: 10
        },
        maxQtd: null,
        image_url: 'https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/MXNL2?wid=532&hei=582&fmt=png-alpha&.v=1618676803000',
        brand: 'Apple'
    },
    {
        title: 'Carregador USB de 5W Apple',
        price: {
            portionX: 12,
            price: 299,
            discontPercentage: 10
        },
        maxQtd: null,
        image_url: 'https://lojaonline.vivo.com.br/medias/sys_master/root/h85/h8b/13313567850526/Carregador5W.png',
        brand: 'Apple'
    },
]