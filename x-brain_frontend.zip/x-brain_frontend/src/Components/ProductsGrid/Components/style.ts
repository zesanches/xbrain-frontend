import styled from 'styled-components'

export const StyledCard = styled.div<{
    isHover: boolean;
}>`
    width: 100%;
    height: 300px;
    border-radius: 10px;
    transition: all .3s ease-in-out;
    padding: 5px;
    overflow: hidden;
    &:hover{
        box-shadow: 0px 0px 10px rgba(0, 0, 0, .3);
        border: 1px solid rgba(0, 0, 0, .2);
    }
    img{
        width: 100%;
        object-fit: contain;
        height: 200px;
    }
    div.actions_box{
        background-color: rgba(255, 255, 255, .8);
        transition: all .3s ease-in-out;
        overflow: hidden;
        transform: ${({ isHover }) => isHover ? `translateY(-110px)` : `translateY(0px)`};
        div.infs_box{
            padding: 10px;
            height: 100px;
            h2{
                font-weight: lighter;
                font-size: 1rem;
            }
            h1{
                font-size: 1.2rem;
            }
            span{
                font-size: .7rem;
                opacity: .7;
            }
        }
        div.control_box{
            height: fit-content;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            div{
                margin-bottom: 10px;
                width: 80%;
                display: flex;
                justify-content: space-between;
                @media (max-width: 800px){
                    width: 80%;
                }
                input{
                    text-align: center;
                    margin-top: 10px;
                    width: 60%;
                    height: 35px;
                    border: 1px solid #ccc;
                    outline: none;
                }
                button.btn_qtd{
                    cursor: pointer;
                    outline: none;
                    border: none;
                    width: 40px;
                    height: 40px;
                    border-radius: 50%;
                    color: rgba(0, 0, 0, .5);
                    background-color: #afbdc4;
                    margin-top: 10px;
                    font-weight: lighter;
                    font-size: 25px;
                }
            }
            button.add{
                background-color: #019cdf;
                width: 80%;
                padding: 8px;
                border-radius: 5px;
                color: #fff;
                font-size: .8rem;
                font-weight: bolder;
                outline: none;
                cursor: pointer;
                border: none;
                transition: all .3s ease-in-out;
                &:hover{
                    transform: scale(1.05);
                }
            }
        }
    }
`

