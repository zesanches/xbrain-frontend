import React, { useEffect, useState } from 'react'
import { toast } from 'react-toastify'
import { Product } from '../../../Models/types'
import { StyledCard } from './style'

export default function ProductCard({
    title,
    price,
    maxQtd,
    image_url,
    brand,
    setNewPrice
}: Product) {
    const [isOnHover, setIsOnHover] = useState(false),
        [qtd, setQtd] = useState(0),
        handleQtd = (isMore?: boolean | undefined, isInput?: boolean, inputQtd?: number) => {
            if (typeof isMore === 'boolean') {
                if (isMore) {
                    if (maxQtd && qtd >= maxQtd) {
                        toast.error(`A quantidade máxima de produtos é ${maxQtd}`, { theme: 'colored' })
                        return
                    } else {
                        setQtd(qtd + 1)
                    }
                } else {
                    if (qtd > 1) {
                        setQtd(qtd - 1)
                    }
                }
            }
            if (isInput && inputQtd) {
                if (maxQtd && inputQtd > maxQtd) {
                    toast.error(`A quantidade máxima de produtos é ${maxQtd}`, { theme: 'colored' })
                }
                setQtd(inputQtd)
            }
        }

    useEffect(() => {
        if (maxQtd && qtd > maxQtd) {
            setQtd(maxQtd)
            toast.error(`A quantidae máxima de produtos é ${maxQtd}`, { theme: 'colored' })
        }
    }, [qtd])

    return (
        <StyledCard
            isHover={isOnHover}
            onMouseEnter={() => setIsOnHover(true)}
            onMouseLeave={() => setIsOnHover(false)}
        >
            <img
                alt={title + ' de ' + brand}
                src={image_url}
            />
            <div className='actions_box'>
                <div className='infs_box'>
                    <h2>{title}</h2>
                    <h1>R$ {price.price},00</h1>
                    <span>Em até {price.portionX}x de R${(price.price / price.portionX).toFixed(2)}</span><br></br>
                    <span>R$ {((price.price - (price.price / price.discontPercentage))).toFixed(2)} à vista ({price.discontPercentage}% de desconto)</span>
                </div>
                <div className='control_box'>
                    <div>
                        <button
                            className='btn_qtd'
                            onClick={() => handleQtd(false)}
                        >-</button>
                        <input
                            type="number"
                            value={qtd || ''}
                            onChange={(e) => setQtd(Number(e.target.value))}
                        />
                        <button
                            className='btn_qtd'
                            onClick={() => handleQtd(true)}
                        >+</button>
                    </div>
                    <button
                        onClick={() => setNewPrice && setNewPrice(price.price)}
                        className='add'
                    >Adicionar</button>
                </div>
            </div>
        </StyledCard>

    )
}
