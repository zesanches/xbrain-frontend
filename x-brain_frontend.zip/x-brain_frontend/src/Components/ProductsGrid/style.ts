import styled from 'styled-components'

export const Grid = styled.section`
    padding: 50px;
    h1.title{
        width: 100%;
        border-bottom: 1px solid rgba(0, 0, 0, .1);
    }
    section{
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(250px, 2fr));
        grid-template-rows: 320px;
        grid-gap: 20px;
        margin: 20px 0;
        place-items: center;
    }
    
    @media (max-width: 400px) {
        display: flex;
        flex-direction: column;
    }
`;