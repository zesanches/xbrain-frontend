import { Product } from '../../Models/types'
import ProductCard from '../ProductsGrid/Components/Card'
import { ListProducts } from './ProductsList'
import { Grid } from './style'

export default function ProductsGrid({
    setPrice,
    price
}: {
    setPrice: (price: number) => void,
    price: number
}) {
    const handlePrice = (_price: number) => {
        setPrice(_price + price)
    }

    return (
        <Grid>
            <h1 className='title'>Produtos</h1>
            <section>
                {ListProducts.map((product: Product, index: number) => (
                    <ProductCard key={index} {...product} setNewPrice={(p: number) => handlePrice(p)} />
                ))}
            </section>
        </Grid>
    )
}