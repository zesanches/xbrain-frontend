import styled from "styled-components";

export const UserSection = styled.section`
    padding: 50px;
    h1.title{
        width: 100%;
        border-bottom: 1px solid rgba(0, 0, 0, .1);
    }
    .css-17024cw-MuiFormControl-root{
        margin: 0 !important;
    }
    section{
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        gap: 30px;
        align-items: flex-start;
        margin: 30px 0;
        @media (max-width: 912px) {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 20px;
        width: 70%;
        }
        @media(max-width: 400px) {
        display: flex;
        flex-direction: column;
        width: 150%;
        }

        
    
    }
    
`