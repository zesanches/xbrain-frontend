import { MenuItem, Select, TextField, InputLabel, FormControl } from '@mui/material'
import React, { useEffect, useState } from 'react'
import { UserSection } from './style'

export default function UserInfos() {
    const [infos, setInfos] = useState<{
        name: string,
        email: string,
        sex: 'Masculino' | 'Feminino' | 'Outro' | 'Prefiro não dizer' | string
    }>({
        name: '',
        email: '',
        sex: '',
    })

    useEffect(() => {
        if (localStorage.getItem('x-brain@auth') === JSON.stringify(infos)) {
            return
        } else {
            if (localStorage.getItem('x-brain@auth')) {
                console.log(localStorage.getItem('x-brain@auth'))
                setInfos(JSON.parse(localStorage.getItem('x-brain@auth') || ''))
            } else {
                localStorage.setItem('x-brain@auth', JSON.stringify(infos))
            }
        }
    }, [infos])

    return (
        <UserSection>
            <h1 className='title'>Dados do Cliente</h1>
            <section>
                <TextField
                    value={infos.name}
                    onChange={(e) => setInfos({ ...infos, name: e.target.value })}
                    required
                    id="outlined-error"
                    label="Nome"
                    fullWidth
                    error={infos.name === ""}
                    helperText={infos.name === "" ? 'Campo Obrigatório' : ' '}
                />
                <TextField
                    value={infos.email}
                    onChange={(e) => setInfos({ ...infos, email: e.target.value })}
                    required
                    id="outlined-error"
                    label="Email"
                    fullWidth
                    error={infos.email === ""}
                    helperText={infos.email === "" ? 'Campo Obrigatório' : ' '}
                />
                <FormControl sx={{ m: 1, minWidth: '20%' }}>
                    <InputLabel id="demo-simple-select-disabled-label">Sexo</InputLabel>
                    <Select
                        value={infos.sex}
                        label="Sexo"
                        onChange={(e) => setInfos({ ...infos, sex: e.target.value })}
                    >
                        <MenuItem value="">
                            <em>Prefiro não dizer</em>
                        </MenuItem>
                        <MenuItem value="Masculino">Masculino</MenuItem>
                        <MenuItem value="Feminino">Feminino</MenuItem>
                        <MenuItem value="Outro">Outro</MenuItem>
                    </Select>
                </FormControl>
            </section>
        </UserSection>
    )
}
