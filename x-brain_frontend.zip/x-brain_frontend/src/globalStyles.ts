import { createGlobalStyle } from 'styled-components';

export const GlobalStyle = createGlobalStyle`
    // RUBIK
    @import url('https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
    
    // LATO
    @import url('https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap');

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        scroll-behavior: smooth;
    }
    body{
        font-family: 'Rubik', sans-serif;
        font-weight: lighter;
        scroll-behavior: smooth;
        color: #546e7a;
        overflow-x: hidden;
        overflow-y: auto !important;
        padding: 0 40px;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
    }
    ::-webkit-scrollbar{
        padding: 5px 0px;
        width: 8px;
        height: 10px;
        border-radius: 15px;
        background-color: rgba(1, 156, 223, 0.2);
    }
    ::-webkit-scrollbar-track{
        width: 15px;
        background: rgb(70, 70, 70, .2);
    }
    ::-webkit-scrollbar-thumb{
        border-radius: 15px;
        background-color: rgba(1, 156, 223, 0.5);
    }
    ::selection {
        background: rgba(1, 156, 223, .7);
    }
    ::-moz-selection {
        background: rgba(1, 156, 223, .7);
    }
`;