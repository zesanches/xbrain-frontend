export type Product = {
    title: string;
    price: {
        portionX: number;
        price: number;
        discontPercentage: number;
    }
    maxQtd: number | null;
    image_url: string;
    brand: string,
    setNewPrice?: (newPrice: number) => void;
}
