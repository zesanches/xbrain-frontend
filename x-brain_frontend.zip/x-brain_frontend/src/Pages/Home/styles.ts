import styled from "styled-components";

export const HomeBox = styled.section`
    
`;