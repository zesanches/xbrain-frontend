import React, { useState } from 'react'
import PriceCounter from '../../Components/PriceCounter/PriceCounter'
import ProductsGrid from '../../Components/ProductsGrid/ProductsGrid'
import UserInfos from '../../Components/UserInfos/UserInfos'

export default function Home() {
    const [total_price, set_total_price] = useState(
        JSON.parse(localStorage.getItem('x-brain@price') ||
            '0'
        ) ||
        0)

    return (
        <div>
            <ProductsGrid
                setPrice={(p) => set_total_price(p)}
                price={total_price}
            />
            <UserInfos />
            <PriceCounter price={total_price} />
        </div>
    )
}

