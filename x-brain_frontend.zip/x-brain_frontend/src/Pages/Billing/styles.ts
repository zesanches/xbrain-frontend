import styled from "styled-components";

export const BillingBox = styled.section`
    display: grid;
    place-items: center;
    background-color: rgb(236,239,241);
    min-height: 100vh;
    width: 100vw;
    margin-left: -40px;
    section{
        height: fit-content;
        width: 30vw;
        padding: 20px;
        border-radius: 5px;
        background-color: rgb(255,255,255);
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        gap: 15px;
        text-align: center;
        h1{
            margin-bottom: 15px;
            font-size: 1.7rem;
            font-weight: bolder;
            font-family: 'Rubik', sans-serif;
        }
        span{
            font-size: 1.5rem;
            font-weight: bolder;
            font-family: 'Rubik', sans-serif;
            strong{
                color: rgb(1, 156, 223);
            }
        }
        img{
            @media(max-width: 768px){
                width: 80%;
            }
        }

        svg{
            font-size: 17rem;
        }
        button{
            text-decoration: none;
            width: fit-content;
            padding: 10px;
            background-color: #ff9800;
            color: #fff;
            border: none;
            outline: none;
            border-radius: 5px;
            font-size: .9rem;
            font-weight: bolder;
            font-family: 'Lato' sans-serif;
            cursor: pointer;
        }
    }
`