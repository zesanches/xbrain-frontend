import React, { useState } from 'react'
import * as MdIcons from 'react-icons/md'
import { useNavigate } from 'react-router-dom'
import BillingImage from '../../Assets/img/Billing.png'

import { BillingBox } from './styles'

export default function Billing() {
    const [user_infos, set_user_infos] = useState(localStorage.getItem('x-brain@auth')),
        [price, set_price] = useState(localStorage.getItem('x-brain@price')),
        navigate = useNavigate(),
        handleNewShop = () => {
            localStorage.setItem('x-brain@price', '0')
            navigate('/', { replace: true })
        }

    return (
        <BillingBox>
            {user_infos && JSON.parse(price || '') > 0 ?
                <section>
                    <h1>{JSON.parse(user_infos)?.name + ',' || 'Por favor, ensira seu para concluir o cadastro.'}</h1>
                    <span>Sua compra no valor <strong>R${JSON.parse(price || '')}</strong> foi finalizada com sucesso</span>
                    <img src={BillingImage}></img>
                    <button onClick={handleNewShop}>
                        INICIAR NOVA COMPRA
                    </button>
                </section> :
                <h1>Ooops! Página não encontrada... Erro: 404</h1>}
        </BillingBox>
    )
}
