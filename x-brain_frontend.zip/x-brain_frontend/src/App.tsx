import { createContext, useState } from 'react'
import { Route, Routes } from 'react-router-dom'
import { GlobalStyle } from './globalStyles'
import { ToastContainer } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css';
import Home from './Pages/Home/Home'
import Billing from './Pages/Billing/Billing';


function App() {
    return (
        <div className="App">
            <GlobalStyle />
            <ToastContainer />
            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/billing" element={<Billing />} />
            </Routes>
        </div>
    )
}

export default App